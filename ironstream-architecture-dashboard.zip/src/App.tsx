/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Activity, 
  Cpu, 
  Database, 
  Layers, 
  LayoutDashboard, 
  Network, 
  Server, 
  Settings, 
  ShieldCheck, 
  Zap,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  BarChart3,
  Search,
  Bell,
  X,
  Save
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  LineChart, 
  Line,
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';

// --- Mock Data ---

const LANGUAGE_DATA = [
  { name: 'Java', count: 320, color: '#f89820', domain: 'ERP, Orders' },
  { name: 'Go', count: 210, color: '#00add8', domain: 'IoT Gateway' },
  { name: 'Python', count: 180, color: '#3776ab', domain: 'ML, Analytics' },
  { name: 'Rust', count: 140, color: '#dea584', domain: 'Real-time' },
  { name: 'C#', count: 100, color: '#239120', domain: 'MES, SCADA' },
  { name: 'Node.js', count: 50, color: '#339933', domain: 'Edge API' },
];

const HEALTH_STATS = [
  { label: 'Healthy', value: 982, color: 'text-emerald-500', icon: CheckCircle2 },
  { label: 'Warning', value: 14, color: 'text-amber-500', icon: AlertTriangle },
  { label: 'Critical', value: 4, color: 'text-rose-500', icon: XCircle },
];

const RECENT_EVENTS = [
  { id: 1, service: 'iot-sensor-node-42', event: 'High Temperature Alert', time: '2m ago', status: 'warning' },
  { id: 2, service: 'order-processor-java', event: 'Batch Order Completed', time: '5m ago', status: 'success' },
  { id: 3, service: 'ml-quality-predictor', event: 'Model Retrained', time: '12m ago', status: 'success' },
  { id: 4, service: 'scada-controller-01', event: 'Connection Timeout', time: '15m ago', status: 'critical' },
  { id: 5, service: 'rust-realtime-engine', event: 'Low Latency Mode Active', time: '22m ago', status: 'success' },
];

const TECH_RADAR = [
  { language: 'Java', status: 'Adopt', reason: 'Enterprise standard for ERP/Orders' },
  { language: 'Go', status: 'Adopt', reason: 'High-performance IoT gateways' },
  { language: 'Rust', status: 'Trial', reason: 'Low-latency safety-critical nodes' },
  { language: 'Python', status: 'Adopt', reason: 'Data science & ML pipelines' },
  { language: 'C#', status: 'Assess', reason: 'Legacy SCADA integration' },
];

// --- Components ---

const StatCard = ({ label, value, icon: Icon, color }: any) => (
  <div className="bg-[#1a1a1a] border border-[#333] p-4 rounded-lg flex items-center gap-4">
    <div className={cn("p-3 rounded-full bg-opacity-10", color.replace('text-', 'bg-'))}>
      <Icon className={cn("w-6 h-6", color)} />
    </div>
    <div>
      <p className="text-xs font-mono text-gray-500 uppercase tracking-wider">{label}</p>
      <p className="text-2xl font-mono font-bold text-white">{value}</p>
    </div>
  </div>
);

const SidebarItem = ({ icon: Icon, label, active, onClick }: any) => (
  <button 
    onClick={onClick}
    className={cn(
      "w-full flex items-center gap-3 px-4 py-3 text-sm font-medium transition-colors duration-200",
      active 
        ? "text-white bg-[#222] border-r-2 border-emerald-500" 
        : "text-gray-400 hover:text-white hover:bg-[#1a1a1a]"
    )}
  >
    <Icon className="w-5 h-5" />
    <span>{label}</span>
  </button>
);

export default function App() {
  const [activeTab, setActiveTab] = useState('Dashboard');
  const [sensorData, setSensorData] = useState<any[]>([]);
  const [selectedNode, setSelectedNode] = useState<number | null>(null);
  const [expandedService, setExpandedService] = useState<string | null>(null);
  const [editingService, setEditingService] = useState<any | null>(null);

  // Simulate real-time sensor data
  useEffect(() => {
    const interval = setInterval(() => {
      setSensorData(prev => {
        const newData = [...prev, {
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          value: Math.floor(Math.random() * 40) + 60
        }].slice(-20);
        return newData;
      });
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-300 font-sans flex overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 border-r border-[#222] bg-[#0d0d0d] flex flex-col">
        <div className="p-6 border-b border-[#222] flex items-center gap-3">
          <div className="w-8 h-8 bg-emerald-500 rounded flex items-center justify-center">
            <Layers className="text-black w-5 h-5" />
          </div>
          <h1 className="text-lg font-bold text-white tracking-tight">IRONSTREAM</h1>
        </div>
        
        <nav className="flex-1 py-4">
          <SidebarItem icon={LayoutDashboard} label="Dashboard" active={activeTab === 'Dashboard'} onClick={() => setActiveTab('Dashboard')} />
          <SidebarItem icon={Server} label="Services" active={activeTab === 'Services'} onClick={() => setActiveTab('Services')} />
          <SidebarItem icon={Network} label="Service Mesh" active={activeTab === 'Mesh'} onClick={() => setActiveTab('Mesh')} />
          <SidebarItem icon={Database} label="Data Stores" active={activeTab === 'Data'} onClick={() => setActiveTab('Data')} />
          <SidebarItem icon={ShieldCheck} label="Security" active={activeTab === 'Security'} onClick={() => setActiveTab('Security')} />
          <SidebarItem icon={Activity} label="Observability" active={activeTab === 'Observability'} onClick={() => setActiveTab('Observability')} />
        </nav>

        <div className="p-4 border-t border-[#222]">
          <div className="bg-[#1a1a1a] p-3 rounded-lg flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center">
              <span className="text-emerald-500 text-xs font-bold">UM</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-white truncate">udayasri@ironstream.com</p>
              <p className="text-[10px] text-gray-500 uppercase">Admin</p>
            </div>
            <Settings className="w-4 h-4 text-gray-500 cursor-pointer hover:text-white" />
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-[#222] bg-[#0d0d0d] flex items-center justify-between px-8">
          <div className="flex items-center gap-4">
            <h2 className="text-xl font-semibold text-white">{activeTab}</h2>
            <div className="h-4 w-px bg-[#333]" />
            <div className="flex items-center gap-2 text-xs text-emerald-500 font-mono">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              SYSTEM OPERATIONAL
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
              <input 
                type="text" 
                placeholder="Search services..." 
                className="bg-[#1a1a1a] border border-[#333] rounded-full py-1.5 pl-10 pr-4 text-xs focus:outline-none focus:border-emerald-500 transition-colors w-64"
              />
            </div>
            <button className="relative p-2 text-gray-400 hover:text-white transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-[#0d0d0d]" />
            </button>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="flex-1 overflow-y-auto p-8 space-y-8 custom-scrollbar">
          {activeTab === 'Dashboard' ? (
            <>
              {/* Top Stats */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard label="Total Services" value="1,024" icon={Layers} color="text-blue-500" />
                {HEALTH_STATS.map(stat => (
                  <StatCard key={stat.label} label={stat.label} value={stat.value} icon={stat.icon} color={stat.color} />
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Language Distribution */}
                <div className="lg:col-span-2 bg-[#0d0d0d] border border-[#222] rounded-xl p-6">
                  <div className="flex items-center justify-between mb-8">
                    <div>
                      <h3 className="text-lg font-semibold text-white">Polyglot Distribution</h3>
                      <p className="text-xs text-gray-500">Service count across 1,000+ microservices</p>
                    </div>
                    <BarChart3 className="w-5 h-5 text-gray-500" />
                  </div>
                  
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={LANGUAGE_DATA} layout="vertical" margin={{ left: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#222" horizontal={false} />
                        <XAxis type="number" hide />
                        <YAxis 
                          dataKey="name" 
                          type="category" 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fill: '#888', fontSize: 12, fontFamily: 'monospace' }}
                        />
                        <Tooltip 
                          cursor={{ fill: '#1a1a1a' }}
                          contentStyle={{ backgroundColor: '#0d0d0d', border: '1px solid #333', borderRadius: '8px' }}
                          itemStyle={{ color: '#fff', fontSize: '12px' }}
                        />
                        <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                          {LANGUAGE_DATA.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} fillOpacity={0.8} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Health Overview Pie */}
                <div className="bg-[#0d0d0d] border border-[#222] rounded-xl p-6">
                  <h3 className="text-lg font-semibold text-white mb-8">Uptime Status</h3>
                  <div className="h-[240px] w-full relative">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={HEALTH_STATS}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {HEALTH_STATS.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color.includes('emerald') ? '#10b981' : entry.color.includes('amber') ? '#f59e0b' : '#f43f5e'} />
                          ))}
                        </Pie>
                      </PieChart>
                    </ResponsiveContainer>
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                      <span className="text-3xl font-mono font-bold text-white">99.8%</span>
                      <span className="text-[10px] text-gray-500 uppercase tracking-widest">Global Uptime</span>
                    </div>
                  </div>
                  <div className="mt-6 space-y-3">
                    {HEALTH_STATS.map(stat => (
                      <div key={stat.label} className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <div className={cn("w-2 h-2 rounded-full", stat.color.replace('text-', 'bg-'))} />
                          <span className="text-gray-400">{stat.label}</span>
                        </div>
                        <span className="font-mono text-white">{stat.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Real-time Sensor Data */}
                <div className="lg:col-span-2 bg-[#0d0d0d] border border-[#222] rounded-xl p-6">
                  <div className="flex items-center justify-between mb-8">
                    <div>
                      <h3 className="text-lg font-semibold text-white">Blast Furnace IoT Stream</h3>
                      <p className="text-xs text-gray-500">Real-time temperature monitoring (°C)</p>
                    </div>
                    <Zap className="w-5 h-5 text-emerald-500" />
                  </div>
                  
                  <div className="h-[250px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={sensorData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                        <XAxis 
                          dataKey="time" 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fill: '#555', fontSize: 10 }}
                        />
                        <YAxis 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{ fill: '#555', fontSize: 10 }}
                          domain={[0, 120]}
                        />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#0d0d0d', border: '1px solid #333', borderRadius: '8px' }}
                          itemStyle={{ color: '#10b981', fontSize: '12px' }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="value" 
                          stroke="#10b981" 
                          strokeWidth={2} 
                          dot={false} 
                          isAnimationActive={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Recent Events */}
                <div className="bg-[#0d0d0d] border border-[#222] rounded-xl p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-semibold text-white">Event Bus</h3>
                    <button className="text-[10px] text-emerald-500 uppercase font-bold hover:underline">View All</button>
                  </div>
                  <div className="space-y-4">
                    {RECENT_EVENTS.map(event => (
                      <div key={event.id} className="group cursor-pointer">
                        <div className="flex items-start gap-4">
                          <div className={cn(
                            "mt-1 w-2 h-2 rounded-full",
                            event.status === 'success' ? 'bg-emerald-500' : 
                            event.status === 'warning' ? 'bg-amber-500' : 'bg-rose-500'
                          )} />
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-medium text-white group-hover:text-emerald-400 transition-colors">{event.event}</p>
                            <p className="text-[10px] text-gray-500 font-mono mt-0.5">{event.service}</p>
                          </div>
                          <span className="text-[10px] text-gray-600 font-mono">{event.time}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Service Grid Preview */}
              <div className="bg-[#0d0d0d] border border-[#222] rounded-xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-white">Active Service Nodes</h3>
                  {selectedNode !== null && (
                    <button 
                      onClick={() => setSelectedNode(null)}
                      className="text-[10px] text-rose-500 uppercase font-bold hover:underline"
                    >
                      Clear Selection
                    </button>
                  )}
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-10 gap-4">
                  {Array.from({ length: 40 }).map((_, i) => {
                    const isWarning = i === 12 || i === 28;
                    const isCritical = i === 5;
                    const isSelected = selectedNode === i;
                    return (
                      <motion.div 
                        key={i} 
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => setSelectedNode(i)}
                        className={cn(
                          "aspect-square rounded border flex items-center justify-center transition-all duration-300 cursor-pointer",
                          isSelected ? "ring-2 ring-white border-white" : "",
                          isCritical ? "bg-rose-500/20 border-rose-500/50" :
                          isWarning ? "bg-amber-500/20 border-amber-500/50" :
                          "bg-emerald-500/10 border-emerald-500/30 hover:bg-emerald-500/20"
                        )}
                      >
                        <div className={cn(
                          "w-1.5 h-1.5 rounded-full",
                          isCritical ? "bg-rose-500 animate-pulse" :
                          isWarning ? "bg-amber-500" :
                          "bg-emerald-500"
                        )} />
                      </motion.div>
                    );
                  })}
                </div>

                <AnimatePresence>
                  {selectedNode !== null && (
                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 20 }}
                      className="mt-8 p-6 bg-[#1a1a1a] border border-[#333] rounded-lg"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-4">
                          <div className="p-3 bg-emerald-500/10 rounded-lg">
                            <Cpu className="w-6 h-6 text-emerald-500" />
                          </div>
                          <div>
                            <h4 className="text-white font-bold">Node-{(selectedNode + 100).toString().padStart(3, '0')}</h4>
                            <p className="text-xs text-gray-500 font-mono">UUID: 8f2d-4b9a-9c1e-{(selectedNode * 1234).toString(16)}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="px-2 py-1 bg-emerald-500/20 text-emerald-500 text-[10px] font-bold rounded uppercase">Active</span>
                          <p className="text-[10px] text-gray-500 mt-1 font-mono">Uptime: 142h 12m</p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-3 gap-6 mt-6">
                        <div className="space-y-1">
                          <p className="text-[10px] text-gray-500 uppercase tracking-wider">CPU Usage</p>
                          <div className="h-1.5 w-full bg-[#333] rounded-full overflow-hidden">
                            <div className="h-full bg-emerald-500" style={{ width: '42%' }} />
                          </div>
                          <p className="text-xs font-mono text-white">42%</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-[10px] text-gray-500 uppercase tracking-wider">Memory</p>
                          <div className="h-1.5 w-full bg-[#333] rounded-full overflow-hidden">
                            <div className="h-full bg-blue-500" style={{ width: '68%' }} />
                          </div>
                          <p className="text-xs font-mono text-white">2.4 / 4.0 GB</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-[10px] text-gray-500 uppercase tracking-wider">Network</p>
                          <p className="text-xs font-mono text-white">↑ 1.2 MB/s ↓ 4.8 MB/s</p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Tech Radar Section */}
              <div className="bg-[#0d0d0d] border border-[#222] rounded-xl p-6">
                <h3 className="text-lg font-semibold text-white mb-6">Internal Tech Radar</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {TECH_RADAR.map(tech => (
                    <div key={tech.language} className="p-4 bg-[#1a1a1a] border border-[#333] rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-bold text-white">{tech.language}</span>
                        <span className={cn(
                          "text-[10px] px-2 py-0.5 rounded font-bold uppercase",
                          tech.status === 'Adopt' ? 'bg-emerald-500/20 text-emerald-500' :
                          tech.status === 'Trial' ? 'bg-blue-500/20 text-blue-500' : 'bg-amber-500/20 text-amber-500'
                        )}>
                          {tech.status}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500">{tech.reason}</p>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : activeTab === 'Services' ? (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold text-white">Service Registry</h3>
                  <p className="text-gray-500 text-sm">Managing 1,024 active microservices across the plant.</p>
                </div>
                <div className="flex gap-2">
                  <button className="px-4 py-2 bg-emerald-500 text-black text-sm font-bold rounded-lg hover:bg-emerald-400 transition-colors">
                    Deploy New Service
                  </button>
                </div>
              </div>

              <div className="bg-[#0d0d0d] border border-[#222] rounded-xl overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-[#111] border-b border-[#222]">
                      <th className="px-6 py-4 text-[10px] font-mono text-gray-500 uppercase tracking-widest">Service Name</th>
                      <th className="px-6 py-4 text-[10px] font-mono text-gray-500 uppercase tracking-widest">Stack</th>
                      <th className="px-6 py-4 text-[10px] font-mono text-gray-500 uppercase tracking-widest">Domain</th>
                      <th className="px-6 py-4 text-[10px] font-mono text-gray-500 uppercase tracking-widest">Status</th>
                      <th className="px-6 py-4 text-[10px] font-mono text-gray-500 uppercase tracking-widest">Instances</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#222]">
                    {LANGUAGE_DATA.map((lang, i) => {
                      const serviceId = `${lang.name.toLowerCase()}-core-service-${i + 1}`;
                      const isExpanded = expandedService === serviceId;
                      
                      return (
                        <React.Fragment key={serviceId}>
                          <tr 
                            onClick={() => setExpandedService(isExpanded ? null : serviceId)}
                            className={cn(
                              "hover:bg-[#1a1a1a] transition-colors cursor-pointer group",
                              isExpanded ? "bg-[#1a1a1a]" : ""
                            )}
                          >
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                <div className={cn(
                                  "w-2 h-2 rounded-full",
                                  isExpanded ? "bg-emerald-400 animate-pulse" : "bg-emerald-500"
                                )} />
                                <span className="text-sm font-medium text-white group-hover:text-emerald-400 transition-colors">
                                  {serviceId}
                                </span>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <span className="text-xs font-mono text-gray-400">{lang.name}</span>
                            </td>
                            <td className="px-6 py-4">
                              <span className="text-xs text-gray-500">{lang.domain}</span>
                            </td>
                            <td className="px-6 py-4">
                              <span className="text-[10px] px-2 py-0.5 bg-emerald-500/10 text-emerald-500 rounded font-bold uppercase">Healthy</span>
                            </td>
                            <td className="px-6 py-4">
                              <span className="text-xs font-mono text-white">{Math.floor(Math.random() * 10) + 2}</span>
                            </td>
                          </tr>
                          
                          <AnimatePresence>
                            {isExpanded && (
                              <tr>
                                <td colSpan={5} className="p-0 bg-[#0a0a0a]">
                                  <motion.div 
                                    initial={{ height: 0, opacity: 0 }}
                                    animate={{ height: 'auto', opacity: 1 }}
                                    exit={{ height: 0, opacity: 0 }}
                                    transition={{ duration: 0.3, ease: "easeInOut" }}
                                    className="overflow-hidden border-x border-b border-[#333] mx-4 mb-4 rounded-b-lg"
                                  >
                                    <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
                                      {/* Metrics Section */}
                                      <div className="space-y-4">
                                        <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
                                          <BarChart3 className="w-3 h-3" /> Metrics
                                        </h4>
                                        <div className="grid grid-cols-2 gap-4">
                                          <div className="bg-[#111] p-3 rounded border border-[#222]">
                                            <p className="text-[10px] text-gray-500 uppercase">Latency</p>
                                            <p className="text-lg font-mono text-white">24ms</p>
                                          </div>
                                          <div className="bg-[#111] p-3 rounded border border-[#222]">
                                            <p className="text-[10px] text-gray-500 uppercase">Throughput</p>
                                            <p className="text-lg font-mono text-white">1.2k/s</p>
                                          </div>
                                          <div className="bg-[#111] p-3 rounded border border-[#222]">
                                            <p className="text-[10px] text-gray-500 uppercase">Error Rate</p>
                                            <p className="text-lg font-mono text-emerald-500">0.02%</p>
                                          </div>
                                          <div className="bg-[#111] p-3 rounded border border-[#222]">
                                            <p className="text-[10px] text-gray-500 uppercase">CPU Load</p>
                                            <p className="text-lg font-mono text-white">12.4%</p>
                                          </div>
                                        </div>
                                      </div>

                                      {/* Logs Section */}
                                      <div className="space-y-4">
                                        <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
                                          <Activity className="w-3 h-3" /> Recent Logs
                                        </h4>
                                        <div className="bg-[#050505] rounded border border-[#222] p-3 font-mono text-[10px] space-y-1 max-h-[160px] overflow-y-auto custom-scrollbar">
                                          <p className="text-gray-500">[2026-03-28 11:17:01] <span className="text-blue-400">INFO</span>: Initializing connection pool...</p>
                                          <p className="text-gray-500">[2026-03-28 11:17:02] <span className="text-blue-400">INFO</span>: Successfully connected to PostgreSQL.</p>
                                          <p className="text-gray-500">[2026-03-28 11:17:05] <span className="text-emerald-400">DEBUG</span>: Processing batch job #4291</p>
                                          <p className="text-gray-500">[2026-03-28 11:17:08] <span className="text-blue-400">INFO</span>: Health check passed.</p>
                                          <p className="text-gray-500">[2026-03-28 11:17:12] <span className="text-amber-400">WARN</span>: Slow query detected (142ms)</p>
                                          <p className="text-gray-500">[2026-03-28 11:17:15] <span className="text-blue-400">INFO</span>: Heartbeat emitted.</p>
                                        </div>
                                      </div>

                                      {/* Config Section */}
                                      <div className="space-y-4">
                                        <div className="flex items-center justify-between">
                                          <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest flex items-center gap-2">
                                            <Settings className="w-3 h-3" /> Configuration
                                          </h4>
                                          <button 
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              setEditingService({
                                                id: serviceId,
                                                name: lang.name,
                                                runtime: lang.name === 'Java' ? 'OpenJDK 21' : lang.name === 'Go' ? '1.22' : '3.12',
                                                replicas: 3,
                                                memory: '512Mi',
                                                autoScale: true
                                              });
                                            }}
                                            className="text-[10px] text-emerald-500 hover:text-emerald-400 font-bold uppercase transition-colors"
                                          >
                                            Edit Configuration
                                          </button>
                                        </div>
                                        <div className="space-y-2">
                                          <div className="flex justify-between text-[10px] border-b border-[#222] pb-1">
                                            <span className="text-gray-500">RUNTIME_VERSION</span>
                                            <span className="text-white font-mono">{lang.name === 'Java' ? 'OpenJDK 21' : lang.name === 'Go' ? '1.22' : '3.12'}</span>
                                          </div>
                                          <div className="flex justify-between text-[10px] border-b border-[#222] pb-1">
                                            <span className="text-gray-500">REPLICA_COUNT</span>
                                            <span className="text-white font-mono">3</span>
                                          </div>
                                          <div className="flex justify-between text-[10px] border-b border-[#222] pb-1">
                                            <span className="text-gray-500">MEMORY_LIMIT</span>
                                            <span className="text-white font-mono">512Mi</span>
                                          </div>
                                          <div className="flex justify-between text-[10px] border-b border-[#222] pb-1">
                                            <span className="text-gray-500">AUTO_SCALE</span>
                                            <span className="text-emerald-500 font-mono">ENABLED</span>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </motion.div>
                                </td>
                              </tr>
                            )}
                          </AnimatePresence>
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ) : activeTab === 'Mesh' ? (
            <div className="bg-[#0d0d0d] border border-[#222] rounded-xl p-8 h-full flex flex-col items-center justify-center text-center">
              <Network className="w-16 h-16 text-emerald-500/20 mb-6" />
              <h3 className="text-2xl font-bold text-white mb-2">Service Mesh Topology</h3>
              <p className="text-gray-500 max-w-md mb-8">
                Visualizing the mTLS-secured communication layer across 1,000+ polyglot microservices.
              </p>
              
              <div className="relative w-full max-w-2xl aspect-video bg-[#111] rounded-lg border border-[#222] overflow-hidden flex items-center justify-center">
                {/* Simplified Mesh Visualization */}
                <div className="absolute inset-0 opacity-20">
                  <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(#333 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
                </div>
                
                <div className="relative flex items-center justify-center gap-12">
                  {['Gateway', 'Auth', 'Orders', 'Inventory', 'IoT'].map((name, i) => (
                    <motion.div 
                      key={name}
                      animate={{ 
                        y: [0, -10, 0],
                        transition: { duration: 3 + i, repeat: Infinity, ease: "easeInOut" }
                      }}
                      className="flex flex-col items-center gap-2"
                    >
                      <div className="w-12 h-12 rounded-lg bg-[#1a1a1a] border border-emerald-500/50 flex items-center justify-center shadow-[0_0_15px_rgba(16,185,129,0.1)]">
                        <Server className="w-6 h-6 text-emerald-500" />
                      </div>
                      <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest">{name}</span>
                    </motion.div>
                  ))}
                  
                  {/* Animated connection lines (simulated) */}
                  <svg className="absolute inset-0 w-full h-full pointer-events-none">
                    <path d="M 100 100 Q 200 50 300 100" stroke="#10b981" strokeWidth="1" fill="none" strokeDasharray="5,5" className="animate-[dash_20s_linear_infinite]" />
                    <path d="M 300 100 Q 400 150 500 100" stroke="#10b981" strokeWidth="1" fill="none" strokeDasharray="5,5" className="animate-[dash_20s_linear_infinite]" />
                  </svg>
                </div>
                
                <div className="absolute bottom-4 left-4 flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span className="text-[10px] text-gray-500 uppercase">mTLS Active</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-blue-500" />
                    <span className="text-[10px] text-gray-500 uppercase">Istio Sidecar</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-full py-20 text-center">
              <div className="p-6 bg-[#1a1a1a] rounded-full mb-6">
                <Settings className="w-12 h-12 text-gray-600 animate-spin-slow" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{activeTab} Module Initializing</h3>
              <p className="text-gray-500 max-w-sm">
                This module is currently being provisioned by the platform engineering team. Check back shortly.
              </p>
            </div>
          )}
        </div>
      </main>

      {/* Config Edit Modal */}
      <AnimatePresence>
        {editingService && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setEditingService(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-md bg-[#0d0d0d] border border-[#333] rounded-xl shadow-2xl overflow-hidden"
            >
              <div className="p-6 border-b border-[#222] flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-500/10 rounded-lg">
                    <Settings className="w-5 h-5 text-emerald-500" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">Edit Configuration</h3>
                    <p className="text-xs text-gray-500 font-mono">{editingService.id}</p>
                  </div>
                </div>
                <button 
                  onClick={() => setEditingService(null)}
                  className="p-2 text-gray-500 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Runtime Version</label>
                  <input 
                    type="text" 
                    defaultValue={editingService.runtime}
                    className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-emerald-500 transition-colors font-mono"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Replica Count</label>
                    <input 
                      type="number" 
                      defaultValue={editingService.replicas}
                      className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-emerald-500 transition-colors font-mono"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Memory Limit</label>
                    <input 
                      type="text" 
                      defaultValue={editingService.memory}
                      className="w-full bg-[#1a1a1a] border border-[#333] rounded-lg px-4 py-2 text-sm text-white focus:outline-none focus:border-emerald-500 transition-colors font-mono"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-[#1a1a1a] rounded-lg border border-[#333]">
                  <div>
                    <p className="text-sm font-medium text-white">Auto Scaling</p>
                    <p className="text-[10px] text-gray-500">Enable horizontal pod autoscaling</p>
                  </div>
                  <button 
                    className={cn(
                      "w-10 h-5 rounded-full relative transition-colors duration-200",
                      editingService.autoScale ? "bg-emerald-500" : "bg-[#333]"
                    )}
                  >
                    <div className={cn(
                      "absolute top-1 w-3 h-3 bg-white rounded-full transition-all duration-200",
                      editingService.autoScale ? "left-6" : "left-1"
                    )} />
                  </button>
                </div>
              </div>

              <div className="p-6 bg-[#111] border-t border-[#222] flex gap-3">
                <button 
                  onClick={() => setEditingService(null)}
                  className="flex-1 px-4 py-2 bg-[#1a1a1a] border border-[#333] text-white text-sm font-bold rounded-lg hover:bg-[#222] transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => {
                    // Mock save
                    setEditingService(null);
                  }}
                  className="flex-1 px-4 py-2 bg-emerald-500 text-black text-sm font-bold rounded-lg hover:bg-emerald-400 transition-colors flex items-center justify-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  Save Changes
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <style>{`
        @keyframes dash {
          to {
            stroke-dashoffset: -100;
          }
        }
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 8s linear infinite;
        }
        .custom-scrollbar::-webkit-scrollbar {
          width: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #222;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #333;
        }
      `}</style>
    </div>
  );
}
